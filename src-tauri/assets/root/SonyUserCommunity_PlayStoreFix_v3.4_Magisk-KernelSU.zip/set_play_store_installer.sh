#!/system/bin/sh

MODDIR=${0%/*}
LOG_FILE="$MODDIR/action.log"
PLAY_STORE="com.android.vending"
USER_ID=$(am get-current-user 2>/dev/null)
[ -n "$USER_ID" ] || USER_ID=0

log() {
  printf '%s\n' "$*"
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE"
}

if [ "$(id -u)" != "0" ]; then
  log "오류: Superuser 권한이 필요합니다."
  exit 1
fi

if ! pm path --user "$USER_ID" "$PLAY_STORE" >/dev/null 2>&1; then
  log "오류: 사용자 $USER_ID에서 Google Play 스토어($PLAY_STORE)를 찾을 수 없습니다."
  exit 1
fi

packages=$(pm list packages -3 --user "$USER_ID" 2>/dev/null | sed 's/^package://')
if [ -z "$packages" ]; then
  log "사용자 $USER_ID에서 처리할 서드파티 앱을 찾지 못했습니다."
  exit 0
fi

total=0
success=0
failed=0

log "사용자 $USER_ID의 서드파티 앱 설치 출처를 Google Play로 변경합니다..."

for package_name in $packages; do
  [ -n "$package_name" ] || continue
  [ "$package_name" = "$PLAY_STORE" ] && continue
  total=$((total + 1))

  result=$(cmd package set-installer "$package_name" "$PLAY_STORE" 2>&1)
  status=$?
  if [ "$status" -eq 0 ] && echo "$result" | grep -q "Success"; then
    success=$((success + 1))
  else
    failed=$((failed + 1))
    log "실패: $package_name :: $result"
  fi
done

sync
log "완료: 전체=$total 성공=$success 실패=$failed"

[ "$failed" -eq 0 ]
