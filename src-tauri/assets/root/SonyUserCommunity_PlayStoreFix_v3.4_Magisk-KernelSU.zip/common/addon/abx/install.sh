#!/system/bin/sh

TOOL_PATH="$MODPATH/common/addon/abx/tools"

current_arch=$(get_arch)
get_arch_status=$?

if [ $get_arch_status -ne 0 ]; then
  exit 1
fi

if [ ! -f "$TOOL_PATH/abx2xml-$current_arch" ] || [ ! -f "$TOOL_PATH/xml2abx-$current_arch" ]; then
  ui_print "오류: $TOOL_PATH에서 $current_arch용 변환 도구를 찾을 수 없습니다."
  exit 1
fi

export PATH="$TOOL_PATH:$PATH"

ln -sf "$TOOL_PATH/abx2xml-$current_arch" "$TOOL_PATH/abx2xml"
ln -sf "$TOOL_PATH/xml2abx-$current_arch" "$TOOL_PATH/xml2abx"

ui_print "$current_arch용 ABX 변환 도구를 준비했습니다."
