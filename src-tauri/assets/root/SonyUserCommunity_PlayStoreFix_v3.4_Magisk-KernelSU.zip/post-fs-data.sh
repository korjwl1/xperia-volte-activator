#!/system/bin/sh

MODPATH="${0%/*}"
MODNAME="${MODPATH##*/}"

PACKAGES_XML="${BKI_PACKAGES_XML:-/data/system/packages.xml}"
BACKUP_DIR="$MODPATH/backup"
MAX_BACKUP_FILES=4
CURRENT_TIMESTAMP=$(date +%s)

case "$MODPATH" in
  /data/adb/modules/*) ;;
  *) MODPATH="$(dirname "$(readlink -f "$0")")" ;;
esac

if [ -f "$MODPATH/util_functions.sh" ]; then
  . "$MODPATH/util_functions.sh"
else
  exit 1
fi

wait_for_data() {
  max_wait_time=5
  wait_interval=1
  i=0

  while [ "$i" -lt "$max_wait_time" ]; do
    if [ -f "$PACKAGES_XML" ] && [ -r "$PACKAGES_XML" ] && [ -w "$PACKAGES_XML" ]; then
      ui_print "$PACKAGES_XML 접근 확인"
      return 0
    fi
    ui_print "/data 준비를 기다리는 중..."
    sleep "$wait_interval"
    i=$((i + wait_interval))
  done

  ui_print "오류: $max_wait_time초 안에 $PACKAGES_XML에 접근하지 못했습니다."
  return 1
}

process_xml() {
  xml_file="$1"
  base_name=$(basename "$xml_file")
  base_name_no_ext="${base_name%.*}"

  xml_temp="$MODPATH/temp_${base_name_no_ext}_$CURRENT_TIMESTAMP.xml"
  xml_backup_file="$BACKUP_DIR/${base_name_no_ext}_$CURRENT_TIMESTAMP.xml"
  abxml_backup_file="$BACKUP_DIR/${base_name_no_ext}_$CURRENT_TIMESTAMP.abxml"

  ui_print "패키지 메타데이터 처리 시작: $xml_file"

  backup_file_path=$(backup_file "$xml_file" "bak")
  backup_status=$?
  if [ "$backup_status" -ne 0 ]; then
    ui_print "오류: 원본 백업에 실패했습니다."
    return 1
  fi

  abxml_original_backup_file="$backup_file_path"

  magic=$(dd if="$abxml_original_backup_file" bs=1 count=3 2>/dev/null)
  if [ "$magic" = "ABX" ]; then
    is_text_xml=false
    source_type="ABX"
  else
    is_text_xml=true
    source_type="Text XML"
  fi
  ui_print "원본 형식: $source_type"

  if boolval "$is_text_xml"; then
    cp "$abxml_original_backup_file" "$xml_temp" || return 1
  else
    if ! abx_to_text "$abxml_original_backup_file" "$xml_temp"; then
      ui_print "오류: ABX를 텍스트 XML로 변환하지 못했습니다."
      cp "$abxml_original_backup_file" "$MODPATH/abx_to_text_error_${base_name_no_ext}_$CURRENT_TIMESTAMP.abx" 2>/dev/null
      rm -f "$xml_temp"
      return 1
    fi
  fi

  # 패키지 항목을 한 줄씩 처리할 수 있도록 정규화합니다.
  sed -i 's/<package /\
<package /g' "$xml_temp"
  sed -i 's#</packages>#\
</packages>#g' "$xml_temp"

  vending_uid=$(sed -n -E '/<package / {
    /name="com\.android\.vending"/ {
      s/.*userId="([^"]*)".*/\1/p
      q
    }
  }' "$xml_temp")

  if [ -z "$vending_uid" ]; then
    ui_print "오류: Google Play 스토어의 userId를 찾지 못했습니다."
    rm -f "$xml_temp"
    return 1
  fi
  ui_print "Google Play 스토어 userId 확인: $vending_uid"

  # 중복 installer 관련 속성을 정리합니다.
  sed -i -E '
  :begin
    s/(([\r\n ]*installer="[^"]*")+)(.*)([\r\n ]*installer="[^"]*")+/\1\3/g
    t begin
  :begin2
    s/(([\r\n ]*installInitiator="[^"]*")+)(.*)([\r\n ]*installInitiator="[^"]*")+/\1\3/g
    t begin2
  :begin3
    s/(([\r\n ]*installerUid(-int)?="[^"]*")+)(.*)([\r\n ]*installerUid(-int)?="[^"]*")+/\1\3/g
    t begin3
  ' "$xml_temp"

  processed_temp="$MODPATH/temp_${base_name_no_ext}_processed_$CURRENT_TIMESTAMP.xml"

  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in
      *'<package '*)
        # 시스템 앱은 변경하지 않습니다.
        if echo "$line" | grep -qE 'system="(true|1)"'; then
          printf '%s\n' "$line"
          continue
        fi

        if echo "$line" | grep -q 'installer='; then
          line=$(echo "$line" | sed -E 's/(installer=")[^"]*/\1com.android.vending/g')
        else
          line=$(echo "$line" | sed -E 's#(/?>)# installer="com.android.vending"\1#')
        fi

        if echo "$line" | grep -q 'installInitiator='; then
          line=$(echo "$line" | sed -E 's/(installInitiator=")[^"]*/\1com.android.vending/g')
        else
          line=$(echo "$line" | sed -E 's#(/?>)# installInitiator="com.android.vending"\1#')
        fi

        if echo "$line" | grep -qE 'installerUid(-int)?='; then
          line=$(echo "$line" | sed -E 's/(installerUid(-int)?=")[^"]*/\1'"$vending_uid"'/g')
        else
          line=$(echo "$line" | sed -E 's#(/?>)# installerUid="'"$vending_uid"'"\1#')
        fi

        line=$(echo "$line" | sed -E 's/[\r\n ]*installOriginator="[^"]*"//g')
        line=$(echo "$line" | sed -E 's/[\r\n ]*isOrphaned="(true|1)"//g')
        line=$(echo "$line" | sed -E 's/[\r\n ]*installInitiatorUninstalled="(true|1)"//g')

        if echo "$line" | grep -q 'packageSource='; then
          line=$(echo "$line" | sed -E 's/packageSource="[^"]*"/packageSource="2"/g')
        else
          line=$(echo "$line" | sed -E 's#(/?>)# packageSource="2"\1#')
        fi

        printf '%s\n' "$line"
        ;;
      *)
        printf '%s\n' "$line"
        ;;
    esac
  done < "$xml_temp" > "$processed_temp"

  mv "$processed_temp" "$xml_temp" || return 1

  rotate_files "${base_name_no_ext}_*.xml" "$MAX_BACKUP_FILES"
  rotate_files "${base_name_no_ext}_*.abxml" "$MAX_BACKUP_FILES"

  if boolval "$is_text_xml"; then
    cp "$xml_temp" "$xml_backup_file" || return 1
    replacement_source="$xml_backup_file"
  else
    if ! text_to_abx "$xml_temp" "$abxml_backup_file"; then
      ui_print "오류: 수정본을 ABX로 변환하지 못해 원본을 유지합니다."
      rm -f "$xml_temp" "$processed_temp"
      return 1
    fi
    replacement_source="$abxml_backup_file"
  fi

  if ! cp -f "$replacement_source" "$xml_file"; then
    ui_print "오류: 수정본 적용에 실패했습니다."
    rm -f "$xml_temp"
    return 1
  fi

  if ! cmp -s "$xml_file" "$replacement_source"; then
    ui_print "오류: 적용 후 파일 검증에 실패했습니다."
    rm -f "$xml_temp"
    return 1
  fi

  rm -f "$xml_temp" "$processed_temp"
  ui_print "패키지 메타데이터 처리 완료: $xml_file"
  return 0
}

if ! command_exists abx2xml || ! command_exists xml2abx; then
  ui_print "ABX 변환 도구를 준비합니다."
  for addon in "$MODPATH"/common/addon/*/install.sh; do
    if [ -f "$addon" ]; then
      . "$addon"
      if [ $? -ne 0 ]; then
        ui_print "오류: ABX 변환 도구 준비에 실패했습니다."
        exit 1
      fi
    fi
  done

  if ! command_exists abx2xml || ! command_exists xml2abx; then
    ui_print "오류: ABX 변환 도구를 사용할 수 없습니다."
    exit 1
  fi
fi

if ! wait_for_data; then
  ui_print "이번 부팅에서는 처리를 건너뜁니다."
  exit 0
fi

if ! process_xml "$PACKAGES_XML"; then
  ui_print "오류: 패키지 메타데이터 수정에 실패했습니다. 백업 파일은 유지됩니다."
  exit 1
fi

for file in "$PACKAGES_XML"; do
  chown system:system "$file"
  chmod 640 "$file"
  if command_exists restorecon; then
    restorecon "$file"
  fi
done

ui_print "작업이 정상적으로 완료되었습니다."
ui_print "백업 위치: $BACKUP_DIR"
ui_print "변경 사항 적용을 위해 재부팅을 권장합니다."
