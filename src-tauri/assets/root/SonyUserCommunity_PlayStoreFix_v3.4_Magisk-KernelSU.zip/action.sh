#!/system/bin/sh

MODDIR=${0%/*}
exec sh "$MODDIR/set_play_store_installer.sh"
