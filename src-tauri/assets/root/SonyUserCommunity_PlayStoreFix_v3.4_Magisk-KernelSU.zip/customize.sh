#!/system/bin/sh

case "$BOOTMODE" in
  true|1) ;;
  *) abort "! Magisk 또는 KernelSU 관리자에서 설치해 주세요. 리커버리 설치는 지원하지 않습니다." ;;
esac

case "$ARCH" in
  arm64) tool_arch="aarch64" ;;
  arm) tool_arch="armv7aeabi" ;;
  x64) tool_arch="x86_64" ;;
  x86) tool_arch="i686" ;;
  *)
    case "$(getprop ro.product.cpu.abi 2>/dev/null)" in
      arm64-v8a) tool_arch="aarch64" ;;
      armeabi-v7a) tool_arch="armv7aeabi" ;;
      x86_64) tool_arch="x86_64" ;;
      x86) tool_arch="i686" ;;
      riscv64) tool_arch="riscv64" ;;
      *) abort "! 지원하지 않는 CPU 아키텍처입니다: $ARCH" ;;
    esac
    ;;
esac

tool_dir="$MODPATH/common/addon/abx/tools"
if [ ! -f "$tool_dir/abx2xml-$tool_arch" ] || [ ! -f "$tool_dir/xml2abx-$tool_arch" ]; then
  abort "! $tool_arch용 ABX 변환 도구를 찾을 수 없습니다."
fi

chmod 0755 "$MODPATH/post-fs-data.sh" \
  "$MODPATH/action.sh" \
  "$MODPATH/set_play_store_installer.sh" \
  "$MODPATH/util_functions.sh" \
  "$MODPATH/common/addon/abx/install.sh"
chmod 0755 "$tool_dir"/abx2xml-* "$tool_dir"/xml2abx-*

root_env="Magisk / KernelSU 호환"
if [ "$KSU" = "true" ] || [ -n "$KSU_VER_CODE" ]; then
  root_env="KernelSU"
elif [ -n "$MAGISK_VER_CODE" ] || [ -n "$MAGISK_VER" ]; then
  root_env="Magisk"
fi

ui_print "****************************************"
ui_print " 소니사용자모임 Play Store 인식 픽스"
ui_print "****************************************"
ui_print "- 감지된 루트 환경: $root_env"
ui_print "- CPU 아키텍처: $ARCH ($tool_arch)"
ui_print "- ABX 변환 도구: 포함됨"
ui_print "- Magisk / KernelSU 공용"
ui_print "- 설치 후 한 번 재부팅해 주세요"
ui_print "- Action: 사용자 앱 설치 출처를 Google Play로 일괄 지정"
