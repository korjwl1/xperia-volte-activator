소니사용자모임 픽스 | UNKNOWN_INSTALLED & Play Store
버전: v3.4.0
호환: Magisk / KernelSU

[기능]
- Play 스토어 외 경로로 설치·복원·업데이트한 사용자 앱의 설치 출처 정보를 Google Play 기준으로 정리합니다.
- UNKNOWN_INSTALLED로 표시되는 설치 메타데이터를 보완합니다.
- 모듈의 Action 버튼을 실행하면 현재 사용자에 설치된 서드파티 앱의 설치 출처를 Google Play로 일괄 지정합니다.
- APK를 다시 설치하지 않는 방식이라 앱 데이터와 split APK 구성을 그대로 유지합니다.
- Android Binary XML(ABX) 변환 도구를 모듈 내부에 포함합니다.

[설치]
1. Magisk 또는 KernelSU 관리자에서 ZIP 파일을 모듈로 설치합니다.
2. 설치가 끝나면 한 번 재부팅합니다.
3. 필요하면 모듈의 Action 버튼을 실행해 사용자 앱의 설치 출처를 Google Play로 일괄 적용합니다.

※ 리커버리 설치용 모듈이 아닙니다.
※ 원본 및 수정본 백업과 로그는 /data/adb/modules/ 아래의 해당 모듈 폴더에 저장됩니다.

[배포]
- 소니사용자모임

[기반 및 크레딧]
- Original combined module: DoubleHack
- Reinstall concept: CITRA
- BetterKnownInstalled package database patcher: T3SL4
- ABX converters: rhythmcache/android-xml-converter

라이선스는 동봉된 LICENSE 파일을 따릅니다.
