#!/system/bin/sh

MODPATH="${0%/*}"
LOG_FILE="$MODPATH/$MODNAME.log"
MAX_LOG_SIZE=$((1024 * 1024))
MAX_LOG_FILES=5

command_exists() {
  command -v "$1" >/dev/null 2>&1
}

boolval() {
  case "$(printf "%s" "${1:-}" | tr '[:upper:]' '[:lower:]')" in
    1|true|on|enabled) return 0 ;;
    0|false|off|disabled) return 1 ;;
    *) return 1 ;;
  esac
}

ui_print() {
  message="$1"
  timestamp=$(date +'%Y-%m-%d %H:%M:%S')

  if [ -f "$LOG_FILE" ]; then
    log_size=$(stat -c%s "$LOG_FILE" 2>/dev/null)
    [ -n "$log_size" ] || log_size=0
    if [ "$log_size" -ge "$MAX_LOG_SIZE" ]; then
      i=$((MAX_LOG_FILES - 1))
      while [ "$i" -ge 1 ]; do
        [ -f "$LOG_FILE.$i" ] && mv -f "$LOG_FILE.$i" "$LOG_FILE.$((i + 1))"
        i=$((i - 1))
      done
      mv -f "$LOG_FILE" "$LOG_FILE.1" 2>/dev/null
    fi
  fi

  printf '[%s] %s\n' "$timestamp" "$message" >> "$LOG_FILE"
}

get_arch() {
  arch=$(getprop ro.product.cpu.abi | tr -d '\r')

  case "$arch" in
    armeabi-v7a) echo "armv7aeabi" ;;
    arm64-v8a) echo "aarch64" ;;
    x86) echo "i686" ;;
    x86_64) echo "x86_64" ;;
    riscv64) echo "riscv64" ;;
    *)
      ui_print "오류: 지원하지 않는 CPU 아키텍처입니다: $arch"
      return 1
      ;;
  esac
}

abx_to_text() {
  input_file="$1"
  output_file="$2"

  ui_print "ABX를 텍스트 XML로 변환합니다: $input_file"

  if [ ! -f "$input_file" ]; then
    ui_print "오류: 입력 파일이 없습니다: $input_file"
    return 1
  fi

  [ -n "$output_file" ] || output_file="${input_file%.*}.xml"

  if [ "$output_file" != "-" ]; then
    output_dir=$(dirname "$output_file")
    if [ ! -w "$output_dir" ]; then
      ui_print "오류: 출력 폴더에 쓸 수 없습니다: $output_dir"
      return 1
    fi
  fi

  converter_log="$MODPATH/abx2xml_$$.log"
  if abx2xml "$input_file" "$output_file" >"$converter_log" 2>&1; then
    result=0
  else
    result=$?
  fi

  while IFS= read -r line; do
    ui_print "abx2xml: $line"
  done < "$converter_log"
  rm -f "$converter_log"

  if [ "$result" -eq 0 ] && [ ! -s "$output_file" ]; then
    ui_print "오류: abx2xml 결과 파일이 비어 있습니다."
    result=1
  fi

  if [ "$result" -ne 0 ]; then
    ui_print "오류: ABX 변환에 실패했습니다: $input_file"
  else
    ui_print "ABX 변환 완료: $output_file"
  fi

  return "$result"
}

text_to_abx() {
  input_file="$1"
  output_file="$2"

  ui_print "텍스트 XML을 ABX로 변환합니다: $input_file"

  if [ ! -f "$input_file" ]; then
    ui_print "오류: 입력 파일이 없습니다: $input_file"
    return 1
  fi

  [ -n "$output_file" ] || output_file="${input_file%.*}.abxml"

  if [ "$output_file" != "-" ]; then
    output_dir=$(dirname "$output_file")
    if [ ! -w "$output_dir" ]; then
      ui_print "오류: 출력 폴더에 쓸 수 없습니다: $output_dir"
      return 1
    fi
  fi

  converter_log="$MODPATH/xml2abx_$$.log"
  if xml2abx "$input_file" "$output_file" >"$converter_log" 2>&1; then
    result=0
  else
    result=$?
  fi

  while IFS= read -r line; do
    ui_print "xml2abx: $line"
  done < "$converter_log"
  rm -f "$converter_log"

  if [ "$result" -eq 0 ] && [ ! -s "$output_file" ]; then
    ui_print "오류: xml2abx 결과 파일이 비어 있습니다."
    result=1
  fi

  if [ "$result" -ne 0 ]; then
    ui_print "오류: ABX 생성에 실패했습니다: $input_file"
  else
    ui_print "ABX 생성 완료: $output_file"
  fi

  return "$result"
}

rotate_files() {
  file_pattern="$1"
  max_files="$2"

  files_to_check=$(find "$BACKUP_DIR" -maxdepth 1 -name "$file_pattern" -type f 2>/dev/null | sort)
  [ -n "$files_to_check" ] || return 0

  num_files=$(printf '%s\n' "$files_to_check" | wc -l)
  if [ "$num_files" -ge "$max_files" ]; then
    files_to_delete=$((num_files - max_files + 1))
    printf '%s\n' "$files_to_check" | head -n "$files_to_delete" | while IFS= read -r file; do
      [ -n "$file" ] && [ -f "$file" ] && rm -f "$file"
    done
  fi
}

backup_file() {
  original_file="$1"
  original_file_basename=$(basename "$original_file")
  original_file_no_ext="${original_file_basename%.*}"
  backup_type="$2"
  backup_file="$BACKUP_DIR/${original_file_no_ext}_$CURRENT_TIMESTAMP.$backup_type"

  [ -d "$BACKUP_DIR" ] || mkdir -p "$BACKUP_DIR"
  rotate_files "${original_file_no_ext}_*.${backup_type}" "$MAX_BACKUP_FILES"

  if cp "$original_file" "$backup_file"; then
    ui_print "백업 생성 완료: $backup_file"
    echo "$backup_file"
    return 0
  fi

  ui_print "오류: 백업 생성에 실패했습니다."
  return 1
}
