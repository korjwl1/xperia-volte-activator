. "$MODPATH/utils.sh" || { echo "! utils.sh를 불러오지 못했습니다"; abort; }

MODVER=$(grep_prop version "$TMPDIR/module.prop")
AUTHOR=$(grep_prop author "$TMPDIR/module.prop")
DEVICE=$(getprop ro.product.device)
MODEL=$(getprop ro.product.model)
BRAND=$(getprop ro.product.brand)
ROOT_VERSION=$(get_root_version)

ui_print "- AshReXcue 부트루프 보호 모듈"
ui_print "- 기기: $BRAND $MODEL"
ui_print "- 루트 환경: $method"
ui_print ""
ui_print "- 초기화 중..."
sleep 0.5

ui_print ""
ui_print ">>> 1단계 : 보호 모드"
ui_print "  1. 일반 (모듈 비활성화)"
ui_print "  2. 강력 (모듈 비활성화 + Recovery 재부팅)"
ui_print "  [볼륨+ = 선택] [볼륨- = 다음]"
ui_print ""

selected_mode=""
while [ -z "$selected_mode" ]; do
    for mode in 1 2; do
        ui_print "  > 모드 $mode 선택?"
        if chooseport; then
            selected_mode="$mode"
            break
        fi
    done
    if [ -z "$selected_mode" ]; then
        ui_print "  ! 다시 선택해 주세요..."
        sleep 1
        ui_print ""
    fi
done

case "$selected_mode" in
    1) smode="DM";  desc="모듈 비활성화" ;;
    2) smode="DMR"; desc="모듈 비활성화 + Recovery" ;;
esac

modify_prop -s "mode" "$selected_mode"
ui_print "  ✔ $desc"

ui_print ""
ui_print ">>> 2단계 : 감지 임계값"
ui_print "  1회 부팅  (민감)"
ui_print "  2회 부팅  (권장)"
ui_print "  3회 부팅  (균형)"
ui_print "  4회 부팅  (여유)"
ui_print ""

selected_threshold=""
while [ -z "$selected_threshold" ]; do
    for t in 1 2 3 4; do
        ui_print "  > 임계값 $t 선택?"
        if chooseport; then
            selected_threshold="$t"
            break
        fi
    done
    if [ -z "$selected_threshold" ]; then
        ui_print "  ! 다시 선택해 주세요..."
        sleep 1
        ui_print ""
    fi
done

modify_prop -s "threshold" "$selected_threshold"
ui_print "  ✔ 부팅 $selected_threshold회"

ui_print ""
ui_print ">>> 3단계 : 스크립트 모니터링"
ui_print "- service.d / post-mount.d도 보호할까요?"
ui_print "  [볼륨+ = 예] [볼륨- = 아니요]"
ui_print ""

if chooseport; then
    monitor_scripts="true"
    ui_print "  ✔ 모니터링 활성화"
else
    monitor_scripts="false"
    ui_print "  ✔ 모니터링 비활성화"
fi

modify_prop -s "monitor_scripts" "$monitor_scripts"

ui_print ""
ui_print ">>> 4단계 : 안정성 모니터링"
ui_print "- 추가 데몬(vold, servicemanager)도 확인할까요?"
ui_print "  [볼륨+ = 예] [볼륨- = 아니요]"
ui_print ""

if chooseport; then
    stability_check="true"
    ui_print "  ✔ 추가 검사 활성화"
else
    stability_check="false"
    ui_print "  ✔ 추가 검사 비활성화"
fi

modify_prop -s "extra_stability" "$stability_check"

ui_print ""
ui_print "- 설정 저장 중..."

if [ -f "$mdir/AshLooper/settings.prop" ]; then
  oldlog=$(get_prop log "$mdir/AshLooper/settings.prop") && modify_prop -s "log" "$oldlog" "$MODPATH/settings.prop"
  ui_print ""
  ui_print ">>> 5단계 : 기존 설정 복원"
  ui_print "- 기존 화이트리스트/안정성 시간을 복원할까요?"
  ui_print "  [볼륨+ = 예] [볼륨- = 아니요]"
  ui_print ""

  if chooseport; then
    ui_print "  ✔ 복원 중..."
    oldlist=$(get_prop whitelist "$mdir/AshLooper/settings.prop") && modify_prop -s "whitelist" "$oldlist" "$MODPATH/settings.prop"
    old_stab=$(get_prop stability_time "$mdir/AshLooper/settings.prop") && modify_prop -s "stability_time" "$old_stab" "$MODPATH/settings.prop"
  else
    ui_print "  ✔ 기본값 사용"
  fi
fi

stability_display=$([ "$stability_check" = "true" ] && echo "켜짐" || echo "꺼짐")
scripts_display=$([ "$monitor_scripts" = "true" ] && echo "켜짐" || echo "꺼짐")
modify_prop -s "description" "🛡️ [모드 $smode | 임계값: 부팅 $selected_threshold회 | 안정성 검사: $stability_display | 부팅 스크립트(.d): $scripts_display] Magisk·KernelSU/Next용 부트루프 보호 · 한국어 번역 제공: 소니사용자모임" "$MODPATH/module.prop"
mkdir -p "$LOG_DIR" || { ui_print "- 오류: '$LOG_DIR' 생성 실패. 설치를 중단합니다." >&2; exit 1; }

[ -f "$JQ" ] && chmod 755 "$JQ"

install_date=$(date '+%Y-%m-%d' 2>/dev/null || echo "알 수 없음")
modify_prop -s "install_date" "$install_date" "$MODPATH/settings.prop"

ui_print ""
ui_print "- 보호 기능 적용을 위해 재부팅해 주세요."
ui_print ""